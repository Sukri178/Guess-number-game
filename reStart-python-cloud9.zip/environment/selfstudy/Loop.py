# Guessing number Game

import random

#from random import randint

number=random.randint(1,10)

#print(number)

x=input("Guess a number")

if number==x:
    print("Congratulations, your guess is correct!")

else:
    print("Sorry, better luck next time!")
