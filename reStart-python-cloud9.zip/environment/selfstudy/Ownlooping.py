print("Welcome to Guess the Number Game!")
print ("The rules are simple. I will think of a number, and you will try to guess it!")

import random

number=random.randint(1,10)

isGuessRight=False

while isGuessRight!=True:
    guess=input("Guess a number between 1 to 10")
    if int(guess)==number:
        print("You guess{}. That is correct! You Win!".format(guess))
        isGuessRight=True
    
    else:
        print("You guessed{}. That is incorrect. Try Again!".format(guess))
        
    