Name=input("Enter your name")

Gender=input("Enter your sex")

