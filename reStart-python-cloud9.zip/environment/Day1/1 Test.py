print ("HellO")
print ("What is going on?")
print ("what am I learning")
print ("Python has three numeric types: int, float, and complex")