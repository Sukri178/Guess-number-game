myvalue=5j

print (myvalue)

print(type(myvalue))

print (str(myvalue))