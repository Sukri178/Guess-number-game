myString="This is my String"
print (myString)

print(type(myString))

print(myString+"is a data type called"+str(type(myString)))


firstString="Don't go chasing"
secondString=" waterfall, you stick to the rivers"
thirdString=" that you used to!"

combinedString=firstString+secondString+thirdString

print (combinedString)

Name=input("Enter your name")
print (Name)

# Age=input("Enter your age") 
# print (Age)

# print("Your name is {0} and you are {1} years old!".format(Name,Age))


print (Name *10)

