x=10
y=20
z=36.9
day="Monday"
month="November"

# print(x,month,y,y)
# print ("Today is",day)
# print ("Temperature of today", z)

print(type(x))
print(type(day))

print(type(z), type(day), type(month))

value="python3.10"
Value2='''Java@_01.3
        RUBY
        iah
        ajsij
        ija'''
        

print (value, Value2)
python3<lab_test>.py

