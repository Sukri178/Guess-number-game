print ("Hello World")
print("This is fun - doing my first coding")
python --version dd

